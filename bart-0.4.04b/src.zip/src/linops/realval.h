
#include "misc/cppwrap.h"

extern struct linop_s* linop_realval_create(unsigned int N, const long dims[__VLA(N)]);

#include "misc/cppwrap.h"

