
#define main_bart main_bbox
#include "bart.c"

