


extern double bessel_i0(double x);

